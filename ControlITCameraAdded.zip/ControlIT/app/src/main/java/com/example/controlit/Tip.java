package com.example.controlit;

public class Tip {
    private String category;
    private String tip;

    public Tip(String category, String tip) {
        this.category = category;
        this.tip = tip;
    }

    public String getCategory() {
        return category;
    }

    public String getTip() {
        return tip;
    }
}
